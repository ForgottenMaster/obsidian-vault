use rand::distributions::Distribution;

fn main() {
    const TRAINING_BATCH_PROPORTION: f64 = 0.8;
    const LEARNING_RATE: f64 = 0.001;
    const SETTLED_DELTA: f64 = 0.00000001;

    let (training_batch, testing_batch) = get_batches(TRAINING_BATCH_PROPORTION);
    let (training_targets, testing_targets) = get_targets(TRAINING_BATCH_PROPORTION);
    let (weights, intercept) = train(
        &training_batch,
        &training_targets,
        LEARNING_RATE,
        SETTLED_DELTA,
    );

    // print out the finishing error on the training batch and the testing batch.
    println!("Final error (training): {}", calculate_error(&forward_pass(&training_batch, &training_targets, &weights, &intercept).p, &training_targets));
    println!("Final error (testing): {}", calculate_error(&forward_pass(&testing_batch, &testing_targets, &weights, &intercept).p, &testing_targets));
}

/// Trains using a linear regression.
/// batch is the input data with each row representing a single entry, and each column representing a feature.
/// targets is a column vector with the same number of rows as entries in the batch.
/// learning_rate is a multiplier to avoid too large swings when updating the weights during iterations.
/// settled_delta is a threshold which terminates the training once the delta between new and old total error is less than this threshold.
fn train(
    batch: &ndarray::Array<f64, ndarray::Ix2>,
    targets: &ndarray::Array<f64, ndarray::Ix2>,
    learning_rate: f64,
    settled_delta: f64,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let (mut weights, mut intercept) = initialize_weights_and_intercept(batch.ncols());
    let mut prev_abs_error = f64::NAN;

    loop {
        let (loss_gradients, abs_error) = {
            let forward_info = forward_pass(&batch, &targets, &weights, &intercept);
            let abs_error = forward_info.abs_error;
            let loss_gradients = backward_pass(forward_info);
            (loss_gradients, abs_error)
        };

        if !abs_error.is_finite() {
            break;
        }

        weights = &weights - (learning_rate * loss_gradients.weights);
        intercept = &intercept - (learning_rate * loss_gradients.intercept);

        if prev_abs_error.is_nan() || ((abs_error - prev_abs_error).abs() > settled_delta) {
            prev_abs_error = abs_error;
        } else {
            break;
        }
    }

    (weights, intercept)
}

/// Initialize the weights and intercept to random numbers to start with.
/// Accepts the number of features we are generating weights for.
fn initialize_weights_and_intercept(
    num_features: usize,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let between = rand::distributions::Uniform::new(0.0_f64, 1.0);
    let mut rng = rand::thread_rng();

    let weights = ndarray::Array::from_shape_vec(
        (num_features, 1),
        (0..num_features).map(|_| between.sample(&mut rng)).collect(),
    )
    .unwrap();
    let intercept = ndarray::Array::from_shape_vec((1, 1), vec![between.sample(&mut rng)]).unwrap();
    (weights, intercept)
}

/// Calculates the error between predictions and targets. This is calculated by taking the elementwise
/// difference between predictions and targets, squaring the difference, and calculating the mean of the resulting
/// vector.
fn calculate_error(
    predictions: &ndarray::Array<f64, ndarray::Ix2>,
    targets: &ndarray::Array<f64, ndarray::Ix2>,
) -> f64 {
    (targets - predictions)
        .map(|elem| elem.powf(2.0))
        .mean()
        .unwrap()
}

/// Performs the forward pass of a linear regression.
/// batch is the data matrix with each row representing a single entry, and each column representing a feature.
/// targets is a column vector with the same number of entries as rows in the batch, representing the measured expected target value for each entry.
/// weights is a column vector with the same number of entries as features in the data set.
/// intercept is a 1x1 matrix with a single entry that is the bias/base term added to calculate the final predictions.
fn forward_pass<'a>(
    batch: &'a ndarray::Array<f64, ndarray::Ix2>,
    targets: &'a ndarray::Array<f64, ndarray::Ix2>,
    weights: &'a ndarray::Array<f64, ndarray::Ix2>,
    intercept: &'a ndarray::Array<f64, ndarray::Ix2>,
) -> ForwardInfo<'a> {
    assert_eq!(batch.nrows(), targets.nrows());
    assert_eq!(batch.ncols(), weights.nrows());
    assert_eq!(intercept.ncols(), 1);
    assert_eq!(intercept.nrows(), 1);

    let n = batch.dot(weights);
    let p = &n + intercept;
    let abs_error = calculate_error(&p, targets);

    ForwardInfo {
        batch,
        targets,
        intercept,
        abs_error,
        n,
        p,
    }
}

/// Given information calculated during the forward pass of the linear regression, this
/// function will perform the backward pass to calculate the gradients of loss for the weights
/// and intercept. These can then be applied to the weights and intercept to update them appropriately
/// during training.
fn backward_pass(forward_info: ForwardInfo) -> LossGradients {
    let dl_dp = -2.0 * (forward_info.targets - forward_info.p);
    let dp_dn = ndarray::Array::ones((forward_info.n.nrows(), forward_info.n.ncols()));
    let dp_db = ndarray::Array::<f64, ndarray::Ix2>::ones((
        forward_info.intercept.nrows(),
        forward_info.intercept.ncols(),
    ));
    let dl_dn = &dl_dp * dp_dn;
    let dn_dw = (*forward_info.batch).clone().reversed_axes();
    let dl_dw = dn_dw.dot(&dl_dn);
    let dl_db = ndarray::Array::ones((1, 1)) * (dl_dp * dp_db).sum();
    LossGradients {
        weights: dl_dw,
        intercept: dl_db,
    }
}

/// Struct just to make it neater to pass information out from the forward pass of the
/// linear regression to the gradient calculation (backward pass).
struct ForwardInfo<'a> {
    batch: &'a ndarray::Array<f64, ndarray::Ix2>,
    targets: &'a ndarray::Array<f64, ndarray::Ix2>,
    intercept: &'a ndarray::Array<f64, ndarray::Ix2>,
    abs_error: f64,
    n: ndarray::Array<f64, ndarray::Ix2>,
    p: ndarray::Array<f64, ndarray::Ix2>,
}

/// Struct which holds the gradients of loss as calculated from the backward pass of the
/// linear regression.
struct LossGradients {
    weights: ndarray::Array<f64, ndarray::Ix2>,
    intercept: ndarray::Array<f64, ndarray::Ix2>,
}

/////////////////////////////////////////////////////////////////////////////
// DATA WRANGLING SECTION
/////////////////////////////////////////////////////////////////////////////
fn checking_status_from_string(string: &str) -> f64 {
    match string {
        "'no checking'" => 0.0,
        "'<0'" => 1.0,
        "'0<=X<200'" => 2.0,
        "'>=200'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn duration_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn credit_history_from_string(string: &str) -> f64 {
    match string {
        "'critical/other existing credit'" => 0.0,
        "'delayed previously'" => 1.0,
        "'existing paid'" => 2.0,
        "'no credits/all paid'" => 3.0,
        "'all paid'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn purpose_from_string(string: &str) -> f64 {
    match string {
        "radio/tv" => 0.0,
        "education" => 1.0,
        "furniture/equipment" => 2.0,
        "'new car'" => 3.0,
        "'used car'" => 4.0,
        "business" => 5.0,
        "'domestic appliance'" => 6.0,
        "repairs" => 7.0,
        "other" => 8.0,
        "retraining" => 9.0,
        _ => unimplemented!("{}", string),
    }
}

fn credit_amount_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn savings_status_from_string(string: &str) -> f64 {
    match string {
        "'no known savings'" => 0.0,
        "'<100'" => 1.0,
        "'100<=X<500'" => 2.0,
        "'500<=X<1000'" => 3.0,
        "'>=1000'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn employment_from_string(string: &str) -> f64 {
    match string {
        "unemployed" => 0.0,
        "'<1'" => 1.0,
        "'1<=X<4'" => 2.0,
        "'4<=X<7'" => 3.0,
        "'>=7'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn installment_commitment_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn personal_status_from_string(string: &str) -> f64 {
    match string {
        "'male single'" => 0.0,
        "'male div/sep'" => 1.0,
        "'male mar/wid'" => 2.0,
        "'female div/dep/mar'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn other_parties_from_string(string: &str) -> f64 {
    match string {
        "guarantor" => 0.0,
        "'co applicant'" => 1.0,
        "none" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn residence_since_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn property_magnitude_from_string(string: &str) -> f64 {
    match string {
        "'no known property'" => 0.0,
        "car" => 1.0,
        "'life insurance'" => 2.0,
        "'real estate'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn age_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn other_payment_plans_from_string(string: &str) -> f64 {
    match string {
        "none" => 0.0,
        "stores" => 1.0,
        "bank" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn housing_from_string(string: &str) -> f64 {
    match string {
        "'for free'" => 0.0,
        "rent" => 1.0,
        "own" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn existing_credits_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn job_from_string(string: &str) -> f64 {
    match string {
        "'unemp/unskilled non res'" => 0.0,
        "'unskilled resident'" => 1.0,
        "skilled" => 2.0,
        "'high qualif/self emp/mgmt'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn num_dependents_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn own_telephone_from_string(string: &str) -> f64 {
    match string {
        "none" => 0.0,
        "yes" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

fn foreign_worker_from_string(string: &str) -> f64 {
    match string {
        "no" => 0.0,
        "yes" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

fn class_from_string(string: &str) -> f64 {
    match string {
        "bad" => 0.0,
        "good" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

/// Returns a tuple of 2D arrays to use as the batches for linear regression: (training, testing).
/// Like get_targets takes a multiplier to determine how many of the full set will be used for training purposes.
fn get_batches(
    training_proportion: f64,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let mut all_input_data_flat = {
        let file = std::fs::File::open("dataset.csv").unwrap();
        let mut reader = csv::Reader::from_reader(file);
        reader
            .records()
            .flat_map(|record| {
                let record = record.unwrap();
                std::iter::once(checking_status_from_string(record.get(0).unwrap()))
                    .chain(std::iter::once(duration_from_string(
                        record.get(1).unwrap(),
                    )))
                    .chain(std::iter::once(credit_history_from_string(
                        record.get(2).unwrap(),
                    )))
                    .chain(std::iter::once(purpose_from_string(record.get(3).unwrap())))
                    .chain(std::iter::once(credit_amount_from_string(
                        record.get(4).unwrap(),
                    )))
                    .chain(std::iter::once(savings_status_from_string(
                        record.get(5).unwrap(),
                    )))
                    .chain(std::iter::once(employment_from_string(
                        record.get(6).unwrap(),
                    )))
                    .chain(std::iter::once(installment_commitment_from_string(
                        record.get(7).unwrap(),
                    )))
                    .chain(std::iter::once(personal_status_from_string(
                        record.get(8).unwrap(),
                    )))
                    .chain(std::iter::once(other_parties_from_string(
                        record.get(9).unwrap(),
                    )))
                    .chain(std::iter::once(residence_since_from_string(
                        record.get(10).unwrap(),
                    )))
                    .chain(std::iter::once(property_magnitude_from_string(
                        record.get(11).unwrap(),
                    )))
                    .chain(std::iter::once(age_from_string(record.get(12).unwrap())))
                    .chain(std::iter::once(other_payment_plans_from_string(
                        record.get(13).unwrap(),
                    )))
                    .chain(std::iter::once(housing_from_string(
                        record.get(14).unwrap(),
                    )))
                    .chain(std::iter::once(existing_credits_from_string(
                        record.get(15).unwrap(),
                    )))
                    .chain(std::iter::once(job_from_string(record.get(16).unwrap())))
                    .chain(std::iter::once(num_dependents_from_string(
                        record.get(17).unwrap(),
                    )))
                    .chain(std::iter::once(own_telephone_from_string(
                        record.get(18).unwrap(),
                    )))
                    .chain(std::iter::once(foreign_worker_from_string(
                        record.get(19).unwrap(),
                    )))
            })
            .collect::<Vec<_>>()
    };

    let max = all_input_data_flat.iter().fold(f64::NEG_INFINITY, |state, elem| {
        if *elem > state {
            *elem
        } else {
            state
        }
    });
    all_input_data_flat.iter_mut().for_each(|elem| *elem /= max);

    let num_records = all_input_data_flat.len() / 20; // 20 features/columns
    let num_training_records = ((num_records as f64) * training_proportion) as usize;
    let num_testing_records = num_records - num_training_records;

    let training_records = ndarray::Array::from_shape_vec(
        (num_training_records, 20),
        all_input_data_flat
            .iter()
            .take(num_training_records * 20)
            .copied()
            .collect(),
    )
    .unwrap();
    let testing_records = ndarray::Array::from_shape_vec(
        (num_testing_records, 20),
        all_input_data_flat
            .iter()
            .skip(num_training_records * 20)
            .copied()
            .collect(),
    )
    .unwrap();

    (training_records, testing_records)
}

/// Returns a tuple of column vectors representing the target values from linear regression: (training, testing)
/// Takes a multiplier between 0 and 1 indicating the percentage/proportion of the full sample set to use for training (rest will be used for testing).
fn get_targets(
    training_proportion: f64,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let all_targets = {
        let file = std::fs::File::open("dataset.csv").unwrap();
        let mut reader = csv::Reader::from_reader(file);
        reader
            .records()
            .map(|record| class_from_string(record.unwrap().get(20).unwrap()))
            .collect::<Vec<_>>()
    };

    let num_targets = all_targets.len();
    let num_training_targets = ((num_targets as f64) * training_proportion) as usize;
    let num_testing_targets = num_targets - num_training_targets;

    let training_targets = ndarray::Array::from_shape_vec(
        (num_training_targets, 1),
        all_targets
            .iter()
            .take(num_training_targets)
            .copied()
            .collect(),
    )
    .unwrap();
    let testing_targets = ndarray::Array::from_shape_vec(
        (num_testing_targets, 1),
        all_targets
            .iter()
            .skip(num_training_targets)
            .copied()
            .collect(),
    )
    .unwrap();

    (training_targets, testing_targets)
}