use rand::distributions::Distribution;

fn main() {
    const TRAINING_BATCH_PROPORTION: f64 = 0.8;
    const LEARNING_RATE: f64 = 0.001;
    const SETTLED_DELTA: f64 = 0.00000001;

    let (training_batch, testing_batch) = get_batches(TRAINING_BATCH_PROPORTION);
    let (training_targets, testing_targets) = get_targets(TRAINING_BATCH_PROPORTION);
    let weight_info = train(
        &training_batch,
        &training_targets,
        LEARNING_RATE,
        SETTLED_DELTA,
        training_batch.ncols()
    );

    // print out the finishing error on the training batch and the testing batch.
    println!("Final error (training): {}", forward_loss(&training_batch, &training_targets, &weight_info).1);
    println!("Final error (testing): {}", forward_loss(&testing_batch, &testing_targets, &weight_info).1);
}

/// Calculates the sigmoid function for a given array. Returns a new array of the same shape
/// as the input array but with the sigmoid function applied.
fn sigmoid(input: &ndarray::Array<f64, ndarray::Ix2>) -> ndarray::Array<f64, ndarray::Ix2> {
    input.mapv(sigmoid_elem)
}

/// Calculates the sigmoid function for a single f64 value.
fn sigmoid_elem(input: f64) -> f64 {
    1.0 / (1.0 + (-input).exp())
}

/// Trains using a linear regression.
/// batch is the input data with each row representing a single entry, and each column representing a feature.
/// targets is a column vector with the same number of rows as entries in the batch.
/// learning_rate is a multiplier to avoid too large swings when updating the weights during iterations.
/// settled_delta is a threshold which terminates the training once the delta between new and old total error is less than this threshold.
fn train(
    batch: &ndarray::Array<f64, ndarray::Ix2>,
    targets: &ndarray::Array<f64, ndarray::Ix2>,
    learning_rate: f64,
    settled_delta: f64,
    num_hidden: usize
) -> WeightInfo {
    let mut weight_info = initialize_weights_and_intercept(batch.ncols(), num_hidden);
    let mut prev_abs_error = f64::NAN;

    loop {
        let (loss_gradients, abs_error) = {
            let (forward_info, abs_error) = forward_loss(&batch, &targets, &weight_info);
            let loss_gradients = loss_gradients(forward_info, &weight_info);
            (loss_gradients, abs_error)
        };

        if !abs_error.is_finite() {
            break;
        }

        weight_info.w1 = &weight_info.w1 - (learning_rate * loss_gradients.w1);
        weight_info.b1 = &weight_info.b1 - (learning_rate * loss_gradients.b1);
        weight_info.w2 = &weight_info.w2 - (learning_rate * loss_gradients.w2);
        weight_info.b2 = &weight_info.b2 - (learning_rate * loss_gradients.b2);

        if prev_abs_error.is_nan() || ((abs_error - prev_abs_error).abs() > settled_delta) {
            prev_abs_error = abs_error;
        } else {
            break;
        }
    }

    weight_info
}

/// Initialize the weights and intercepts to random numbers to start with.
/// Takes in the number of features to generate weights for, along with the number
/// of hidden features.
fn initialize_weights_and_intercept(
    num_features: usize,
    num_hidden: usize
) -> WeightInfo {
    let between = rand::distributions::Uniform::new(0.0_f64, 1.0);
    let mut rng = rand::thread_rng();

    let w1 = ndarray::Array::from_shape_vec(
        (num_features, num_hidden),
        (0..num_features*num_hidden).map(|_| between.sample(&mut rng)).collect(),
    )
    .unwrap();
    let b1 = ndarray::Array::from_shape_vec((1, num_hidden), (0..num_hidden).map(|_| between.sample(&mut rng)).collect()).unwrap();
    let w2 = ndarray::Array::from_shape_vec((num_hidden, 1), (0..num_hidden).map(|_| between.sample(&mut rng)).collect()).unwrap();
    let b2 = ndarray::Array::from_shape_vec((1, 1), vec![between.sample(&mut rng)]).unwrap();

    WeightInfo {
        w1,
        b1,
        w2,
        b2
    }
}

/// Calculates the error between predictions and targets. This is calculated by taking the elementwise
/// difference between predictions and targets, squaring the difference, and calculating the mean of the resulting
/// vector.
fn calculate_error(
    predictions: &ndarray::Array<f64, ndarray::Ix2>,
    targets: &ndarray::Array<f64, ndarray::Ix2>,
) -> f64 {
    (targets - predictions)
        .map(|elem| elem.powf(2.0))
        .mean()
        .unwrap()
}

/// Performs the forward pass for a neural network and computes the
/// loss/error value between targets.
fn forward_loss<'a>(
    x: &'a ndarray::Array<f64, ndarray::Ix2>,
    y: &'a ndarray::Array<f64, ndarray::Ix2>,
    weight_info: &'a WeightInfo
) -> (ForwardInfo<'a>, f64) {
    let m1 = x.dot(&weight_info.w1);
    let n1 = &m1 + &weight_info.b1;
    let o1 = sigmoid(&n1);
    let m2 = o1.dot(&weight_info.w2);
    let p = &m2 + &weight_info.b2;
    let loss = calculate_error(&p, y);

    (ForwardInfo {
        x,
        m1,
        n1,
        o1,
        m2,
        p,
        y
    }, loss)
}

/// Given information calculated during the forward pass of the neural network
/// this function will calculate the loss gradients to be applied for the next
/// iteration.
fn loss_gradients(forward_info: ForwardInfo, weight_info: &WeightInfo) -> LossGradients {
    let dldp = -(forward_info.y - forward_info.p);
    let dpdm2: ndarray::Array<f64, ndarray::Ix2> = ndarray::Array::ones(forward_info.m2.raw_dim());
    let dldm2 = &dldp * &dpdm2;
    let dpdb2: ndarray::Array<f64, ndarray::Ix2> = ndarray::Array::ones(weight_info.b2.raw_dim());
    let dldb2 = (&dldp * &dpdb2).map_axis(ndarray::Axis(0), |view| view.into_iter().sum());
    let dm2dw2 = forward_info.o1.reversed_axes();
    let dldw2 = dm2dw2.dot(&dldp);
    let dm2do1 = weight_info.w2.clone().reversed_axes();
    let dldo1 = dldm2.dot(&dm2do1);
    let do1dn1 = sigmoid(&forward_info.n1) * sigmoid(&forward_info.n1).map(|elem| 1.0 - elem);
    let dldn1 = dldo1 * do1dn1;
    let dn1db1: ndarray::Array<f64, ndarray::Ix2> = ndarray::Array::ones(weight_info.b1.raw_dim());
    let dn1dm1: ndarray::Array<f64, ndarray::Ix2> = ndarray::Array::ones(forward_info.m1.raw_dim());
    let dldb1 = (&dldn1 * &dn1db1).map_axis(ndarray::Axis(0), |view| view.into_iter().sum());
    let dldm1 = dldn1 * dn1dm1;
    let dm1dw1 = forward_info.x.clone().reversed_axes();
    let dldw1 = dm1dw1.dot(&dldm1);
    let b2 = ndarray::Array::from_shape_vec((1, 1), dldb2.into_iter().collect()).unwrap();
    let b1len = dldb1.len();
    let b1 = ndarray::Array::from_shape_vec((1, b1len), dldb1.into_iter().collect()).unwrap();
    LossGradients {
        w2: dldw2,
        b2,
        w1: dldw1,
        b1
    }
}

/// Struct just to make it neater to pass information out from the forward pass of the
/// neural network to the gradient calculation (backward pass).
struct ForwardInfo<'a> {
    x: &'a ndarray::Array<f64, ndarray::Ix2>,
    m1: ndarray::Array<f64, ndarray::Ix2>,
    n1: ndarray::Array<f64, ndarray::Ix2>,
    o1: ndarray::Array<f64, ndarray::Ix2>,
    m2: ndarray::Array<f64, ndarray::Ix2>,
    p: ndarray::Array<f64, ndarray::Ix2>,
    y: &'a ndarray::Array<f64, ndarray::Ix2>
}

/// Struct which holds the gradients of loss as calculated from the backward pass of the
/// neural network.
struct LossGradients {
    w1: ndarray::Array<f64, ndarray::Ix2>,
    b1: ndarray::Array<f64, ndarray::Ix2>,
    w2: ndarray::Array<f64, ndarray::Ix2>,
    b2: ndarray::Array<f64, ndarray::Ix2>
}

/// Struct that bundles up the weights and intercepts for the neural network implementation
/// after being generated by the init weights function.
struct WeightInfo {
    w1: ndarray::Array<f64, ndarray::Ix2>,
    b1: ndarray::Array<f64, ndarray::Ix2>,
    w2: ndarray::Array<f64, ndarray::Ix2>,
    b2: ndarray::Array<f64, ndarray::Ix2>
}

/////////////////////////////////////////////////////////////////////////////
// DATA WRANGLING SECTION
/////////////////////////////////////////////////////////////////////////////
fn checking_status_from_string(string: &str) -> f64 {
    match string {
        "'no checking'" => 0.0,
        "'<0'" => 1.0,
        "'0<=X<200'" => 2.0,
        "'>=200'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn duration_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn credit_history_from_string(string: &str) -> f64 {
    match string {
        "'critical/other existing credit'" => 0.0,
        "'delayed previously'" => 1.0,
        "'existing paid'" => 2.0,
        "'no credits/all paid'" => 3.0,
        "'all paid'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn purpose_from_string(string: &str) -> f64 {
    match string {
        "radio/tv" => 0.0,
        "education" => 1.0,
        "furniture/equipment" => 2.0,
        "'new car'" => 3.0,
        "'used car'" => 4.0,
        "business" => 5.0,
        "'domestic appliance'" => 6.0,
        "repairs" => 7.0,
        "other" => 8.0,
        "retraining" => 9.0,
        _ => unimplemented!("{}", string),
    }
}

fn credit_amount_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn savings_status_from_string(string: &str) -> f64 {
    match string {
        "'no known savings'" => 0.0,
        "'<100'" => 1.0,
        "'100<=X<500'" => 2.0,
        "'500<=X<1000'" => 3.0,
        "'>=1000'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn employment_from_string(string: &str) -> f64 {
    match string {
        "unemployed" => 0.0,
        "'<1'" => 1.0,
        "'1<=X<4'" => 2.0,
        "'4<=X<7'" => 3.0,
        "'>=7'" => 4.0,
        _ => unimplemented!("{}", string),
    }
}

fn installment_commitment_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn personal_status_from_string(string: &str) -> f64 {
    match string {
        "'male single'" => 0.0,
        "'male div/sep'" => 1.0,
        "'male mar/wid'" => 2.0,
        "'female div/dep/mar'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn other_parties_from_string(string: &str) -> f64 {
    match string {
        "guarantor" => 0.0,
        "'co applicant'" => 1.0,
        "none" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn residence_since_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn property_magnitude_from_string(string: &str) -> f64 {
    match string {
        "'no known property'" => 0.0,
        "car" => 1.0,
        "'life insurance'" => 2.0,
        "'real estate'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn age_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn other_payment_plans_from_string(string: &str) -> f64 {
    match string {
        "none" => 0.0,
        "stores" => 1.0,
        "bank" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn housing_from_string(string: &str) -> f64 {
    match string {
        "'for free'" => 0.0,
        "rent" => 1.0,
        "own" => 2.0,
        _ => unimplemented!("{}", string),
    }
}

fn existing_credits_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn job_from_string(string: &str) -> f64 {
    match string {
        "'unemp/unskilled non res'" => 0.0,
        "'unskilled resident'" => 1.0,
        "skilled" => 2.0,
        "'high qualif/self emp/mgmt'" => 3.0,
        _ => unimplemented!("{}", string),
    }
}

fn num_dependents_from_string(string: &str) -> f64 {
    string.parse().unwrap()
}

fn own_telephone_from_string(string: &str) -> f64 {
    match string {
        "none" => 0.0,
        "yes" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

fn foreign_worker_from_string(string: &str) -> f64 {
    match string {
        "no" => 0.0,
        "yes" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

fn class_from_string(string: &str) -> f64 {
    match string {
        "bad" => 0.0,
        "good" => 1.0,
        _ => unimplemented!("{}", string),
    }
}

/// Returns a tuple of 2D arrays to use as the batches for linear regression: (training, testing).
/// Like get_targets takes a multiplier to determine how many of the full set will be used for training purposes.
fn get_batches(
    training_proportion: f64,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let mut all_input_data_flat = {
        let file = std::fs::File::open("dataset.csv").unwrap();
        let mut reader = csv::Reader::from_reader(file);
        reader
            .records()
            .flat_map(|record| {
                let record = record.unwrap();
                std::iter::once(checking_status_from_string(record.get(0).unwrap()))
                    .chain(std::iter::once(duration_from_string(
                        record.get(1).unwrap(),
                    )))
                    .chain(std::iter::once(credit_history_from_string(
                        record.get(2).unwrap(),
                    )))
                    .chain(std::iter::once(purpose_from_string(record.get(3).unwrap())))
                    .chain(std::iter::once(credit_amount_from_string(
                        record.get(4).unwrap(),
                    )))
                    .chain(std::iter::once(savings_status_from_string(
                        record.get(5).unwrap(),
                    )))
                    .chain(std::iter::once(employment_from_string(
                        record.get(6).unwrap(),
                    )))
                    .chain(std::iter::once(installment_commitment_from_string(
                        record.get(7).unwrap(),
                    )))
                    .chain(std::iter::once(personal_status_from_string(
                        record.get(8).unwrap(),
                    )))
                    .chain(std::iter::once(other_parties_from_string(
                        record.get(9).unwrap(),
                    )))
                    .chain(std::iter::once(residence_since_from_string(
                        record.get(10).unwrap(),
                    )))
                    .chain(std::iter::once(property_magnitude_from_string(
                        record.get(11).unwrap(),
                    )))
                    .chain(std::iter::once(age_from_string(record.get(12).unwrap())))
                    .chain(std::iter::once(other_payment_plans_from_string(
                        record.get(13).unwrap(),
                    )))
                    .chain(std::iter::once(housing_from_string(
                        record.get(14).unwrap(),
                    )))
                    .chain(std::iter::once(existing_credits_from_string(
                        record.get(15).unwrap(),
                    )))
                    .chain(std::iter::once(job_from_string(record.get(16).unwrap())))
                    .chain(std::iter::once(num_dependents_from_string(
                        record.get(17).unwrap(),
                    )))
                    .chain(std::iter::once(own_telephone_from_string(
                        record.get(18).unwrap(),
                    )))
                    .chain(std::iter::once(foreign_worker_from_string(
                        record.get(19).unwrap(),
                    )))
            })
            .collect::<Vec<_>>()
    };

    let max = all_input_data_flat.iter().fold(f64::NEG_INFINITY, |state, elem| {
        if *elem > state {
            *elem
        } else {
            state
        }
    });
    all_input_data_flat.iter_mut().for_each(|elem| *elem /= max);

    let num_records = all_input_data_flat.len() / 20; // 20 features/columns
    let num_training_records = ((num_records as f64) * training_proportion) as usize;
    let num_testing_records = num_records - num_training_records;

    let training_records = ndarray::Array::from_shape_vec(
        (num_training_records, 20),
        all_input_data_flat
            .iter()
            .take(num_training_records * 20)
            .copied()
            .collect(),
    )
    .unwrap();
    let testing_records = ndarray::Array::from_shape_vec(
        (num_testing_records, 20),
        all_input_data_flat
            .iter()
            .skip(num_training_records * 20)
            .copied()
            .collect(),
    )
    .unwrap();

    (training_records, testing_records)
}

/// Returns a tuple of column vectors representing the target values from linear regression: (training, testing)
/// Takes a multiplier between 0 and 1 indicating the percentage/proportion of the full sample set to use for training (rest will be used for testing).
fn get_targets(
    training_proportion: f64,
) -> (
    ndarray::Array<f64, ndarray::Ix2>,
    ndarray::Array<f64, ndarray::Ix2>,
) {
    let all_targets = {
        let file = std::fs::File::open("dataset.csv").unwrap();
        let mut reader = csv::Reader::from_reader(file);
        reader
            .records()
            .map(|record| class_from_string(record.unwrap().get(20).unwrap()))
            .collect::<Vec<_>>()
    };

    let num_targets = all_targets.len();
    let num_training_targets = ((num_targets as f64) * training_proportion) as usize;
    let num_testing_targets = num_targets - num_training_targets;

    let training_targets = ndarray::Array::from_shape_vec(
        (num_training_targets, 1),
        all_targets
            .iter()
            .take(num_training_targets)
            .copied()
            .collect(),
    )
    .unwrap();
    let testing_targets = ndarray::Array::from_shape_vec(
        (num_testing_targets, 1),
        all_targets
            .iter()
            .skip(num_training_targets)
            .copied()
            .collect(),
    )
    .unwrap();

    (training_targets, testing_targets)
}